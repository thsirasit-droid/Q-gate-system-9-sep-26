import { useState, useEffect, useCallback } from 'react';
import { supabase, type ProblemHistory } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { todayISO, formatDate, createSignedAttachmentUrl } from '@/lib/utils';
import {
  History, Plus, X, Save, FileText, Download, Search,
} from 'lucide-react';

export default function ProblemHistoryTab() {
  const { profile } = useAuth();
  const { notify } = useToast();

  const [records, setRecords] = useState<ProblemHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    const { data } = await supabase
      .from('problem_history')
      .select('*')
      .order('record_date', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(100);
    setRecords((data as ProblemHistory[]) ?? []);
  }, []);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  const filtered = search
    ? records.filter(
        (r) =>
          r.part_no.toLowerCase().includes(search.toLowerCase()) ||
          r.part_name.toLowerCase().includes(search.toLowerCase()) ||
          r.problem.toLowerCase().includes(search.toLowerCase()) ||
          r.customer.toLowerCase().includes(search.toLowerCase())
      )
    : records;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <History className="w-6 h-6 text-teal-600" />
            ประวัติปัญหา
          </h2>
          <p className="text-slate-500 text-sm mt-1">บันทึกประวัติปัญหาที่เกิดขึ้น พร้อมไฟล์แนบ</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <Plus className="w-4 h-4" /> เพิ่มประวัติปัญหา
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="form-input pl-9"
          placeholder="ค้นหาด้วย Part No, ชื่อ, ปัญหา, ลูกค้า..."
        />
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-slate-400">กำลังโหลด...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-400">ยังไม่มีประวัติปัญหา</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-600 text-xs uppercase tracking-wider">
                <tr>
                  <th className="text-left px-4 py-3 font-semibold">วันที่</th>
                  <th className="text-left px-4 py-3 font-semibold">Part No</th>
                  <th className="text-left px-4 py-3 font-semibold">Part Name</th>
                  <th className="text-left px-4 py-3 font-semibold">ลูกค้า</th>
                  <th className="text-left px-4 py-3 font-semibold">ปัญหา</th>
                  <th className="text-left px-4 py-3 font-semibold">รายละเอียด</th>
                  <th className="text-left px-4 py-3 font-semibold">การแก้ไข</th>
                  <th className="text-left px-4 py-3 font-semibold">ไฟล์</th>
                  <th className="text-left px-4 py-3 font-semibold">ผู้บันทึก</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((r) => (
                  <ProblemRow key={r.id} record={r} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showForm && (
        <ProblemForm
          onClose={() => setShowForm(false)}
          onSaved={() => {
            setShowForm(false);
            load();
          }}
          profile={profile!}
        />
      )}
    </div>
  );
}

function ProblemRow({ record }: { record: ProblemHistory }) {
  const [urls, setUrls] = useState<string[]>([]);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      const result: string[] = [];
      for (const p of record.file_paths ?? []) {
        const u = await createSignedAttachmentUrl(p);
        if (u && active) result.push(u);
      }
      if (active) setUrls(result);
    })();
    return () => { active = false; };
  }, [record.file_paths]);

  return (
    <tr className="hover:bg-slate-50">
      <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{formatDate(record.record_date)}</td>
      <td className="px-4 py-3 font-medium text-slate-800">{record.part_no}</td>
      <td className="px-4 py-3 text-slate-600">{record.part_name}</td>
      <td className="px-4 py-3 text-slate-600">{record.customer}</td>
      <td className="px-4 py-3 text-slate-700 max-w-[200px] truncate">{record.problem}</td>
      <td className="px-4 py-3 text-slate-500 max-w-[200px]">
        {record.problem_detail && (
          <>
            <span className={expanded ? '' : 'truncate block'}>{record.problem_detail}</span>
            <button onClick={() => setExpanded(!expanded)} className="text-xs text-cyan-600 hover:underline">
              {expanded ? 'ย่อ' : 'อ่านเพิ่ม'}
            </button>
          </>
        )}
      </td>
      <td className="px-4 py-3 text-slate-500 max-w-[200px] truncate">{record.correction ?? '-'}</td>
      <td className="px-4 py-3">
        {urls.length > 0 ? (
          <div className="flex gap-1">
            {urls.map((u, i) => (
              <a key={i} href={u} target="_blank" rel="noreferrer" className="text-cyan-600 hover:text-cyan-700">
                <FileText className="w-4 h-4" />
              </a>
            ))}
          </div>
        ) : (
          <span className="text-slate-300">-</span>
        )}
      </td>
      <td className="px-4 py-3 text-slate-500 whitespace-nowrap">{record.user_name}</td>
    </tr>
  );
}

function ProblemForm({
  onClose,
  onSaved,
  profile,
}: {
  onClose: () => void;
  onSaved: () => void;
  profile: { id: string; full_name: string };
}) {
  const { notify } = useToast();
  const [date, setDate] = useState(todayISO());
  const [partName, setPartName] = useState('');
  const [partNo, setPartNo] = useState('');
  const [customer, setCustomer] = useState('');
  const [problem, setProblem] = useState('');
  const [problemDetail, setProblemDetail] = useState('');
  const [correction, setCorrection] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!partNo.trim() || !partName.trim() || !customer.trim() || !problem.trim()) {
      notify('error', 'กรุณากรอกข้อมูลให้ครบ (Part No, Part Name, ลูกค้า, ปัญหา)');
      return;
    }
    setSaving(true);

    const filePaths: string[] = [];
    for (const f of files) {
      const ext = f.name.split('.').pop();
      const path = `${profile.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from('attachments').upload(path, f);
      if (error) {
        notify('error', 'อัปโหลดไฟล์ไม่สำเร็จ: ' + error.message);
        setSaving(false);
        return;
      }
      filePaths.push(path);
    }

    const { error } = await supabase.from('problem_history').insert({
      record_date: date,
      part_name: partName.trim(),
      part_no: partNo.trim(),
      customer: customer.trim(),
      problem: problem.trim(),
      problem_detail: problemDetail.trim() || null,
      correction: correction.trim() || null,
      file_paths: filePaths,
      user_id: profile.id,
      user_name: profile.full_name,
    });
    if (error) {
      notify('error', 'บันทึกไม่สำเร็จ: ' + error.message);
      setSaving(false);
      return;
    }
    notify('success', 'บันทึกประวัติปัญหาเรียบร้อยแล้ว');
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 sticky top-0 bg-white">
          <h3 className="font-bold text-slate-800 text-lg">เพิ่มประวัติปัญหา</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">วันที่</label>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="form-input" />
            </div>
            <div>
              <label className="form-label">ลูกค้า</label>
              <input type="text" value={customer} onChange={(e) => setCustomer(e.target.value)} className="form-input" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">Part No</label>
              <input type="text" value={partNo} onChange={(e) => setPartNo(e.target.value)} className="form-input" />
            </div>
            <div>
              <label className="form-label">Part Name</label>
              <input type="text" value={partName} onChange={(e) => setPartName(e.target.value)} className="form-input" />
            </div>
          </div>
          <div>
            <label className="form-label">ปัญหา</label>
            <input type="text" value={problem} onChange={(e) => setProblem(e.target.value)} className="form-input" placeholder="สรุปปัญหา" />
          </div>
          <div>
            <label className="form-label">รายละเอียดปัญหา</label>
            <textarea value={problemDetail} onChange={(e) => setProblemDetail(e.target.value)} className="form-input min-h-[80px]" />
          </div>
          <div>
            <label className="form-label">การแก้ไข</label>
            <textarea value={correction} onChange={(e) => setCorrection(e.target.value)} className="form-input min-h-[80px]" />
          </div>
          <div>
            <label className="form-label">แนบไฟล์</label>
            <div className="flex items-center gap-2 flex-wrap">
              {files.map((f, i) => (
                <div key={i} className="flex items-center gap-1.5 bg-slate-100 rounded-lg px-3 py-1.5 text-sm text-slate-600">
                  <FileText className="w-4 h-4 text-slate-400" />
                  <span className="max-w-[120px] truncate">{f.name}</span>
                  <button onClick={() => setFiles((prev) => prev.filter((_, idx) => idx !== i))} className="text-red-400 hover:text-red-600">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border-2 border-dashed border-slate-300 cursor-pointer hover:border-cyan-500 transition-colors text-sm text-slate-500">
                <Download className="w-4 h-4" /> เพิ่มไฟล์
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    const newFiles = Array.from(e.target.files ?? []);
                    setFiles((prev) => [...prev, ...newFiles]);
                  }}
                />
              </label>
            </div>
          </div>
        </div>
        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">
          <button onClick={onClose} className="btn-secondary">ยกเลิก</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            <Save className="w-4 h-4" />
            {saving ? 'กำลังบันทึก...' : 'บันทึกข้อมูล'}
          </button>
        </div>
      </div>
    </div>
  );
}
